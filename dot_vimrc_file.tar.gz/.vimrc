" ========== 插件管理器启动 适配vim9.0==========
call plug#begin('~/.vim/plugged')

" 在这里写所有插件
" 示例1：C/C++ 语法高亮、缩进增强
Plug 'preservim/nerdtree'        " 文件树侧边栏
Plug 'vim-airline/vim-airline'   " 底部状态栏美化
Plug 'octol/vim-cpp-enhanced-highlight' " C++高亮
Plug 'rhysd/vim-clang-format'    " C/C++ 自动格式化


" C/C++ 智能补全核心
Plug 'neoclide/coc.nvim', {'branch': 'release'}
" ========== 结束插件区块 ==========
call plug#end()

" ========== 基础配置（可选）==========
set number
set tabstop=4
set shiftwidth=4
set expandtab
syntax enable
filetype plugin indent on
" Tab 触发补全
inoremap <silent><expr> <TAB>
\ coc#pum#visible() ? coc#pum#next(1) :
\ CheckBackspace() ? "\<Tab>" :
\ coc#refresh()
inoremap <silent><expr> <S-TAB> coc#pum#visible() ? coc#pum#prev(1) : "\<C-h>"
inoremap <silent><expr> <CR> coc#pum#visible() ? coc#pum#confirm() : "\<CR>"
" ===== 文件跳转配置 =====
" ========== coc LSP 强制绑定跳转快捷键 ==========
nmap gd <Plug>(coc-definition)    " 跳定义（进头文件核心）
nmap gr <Plug>(coc-references)    " 查所有引用
nmap gi <Plug>(coc-implementation)" 跳实现
nmap gT <Plug>(coc-type-definition)" 跳结构体类型
nmap K  <Plug>(coc-hover)         " 悬停看函数文档

" F4 .h <-> .cpp 双向切换
nnoremap <F4> :CocCommand clangd.switchSourceHeader<CR>
" F4 h/cpp切换
nnoremap <F4> :CocCommand clangd.switchSourceHeader<CR>

" F2/F3 buffer切换
nnoremap <F2> :bprev<CR>
nnoremap <F3> :bnext<CR>

" F6 NERDTree
nnoremap <F6> :NERDTreeToggle<CR>

" Ctrl+p 模糊搜文件
nnoremap <C-p> :Files<CR>

" gf 查找文件补充路径
set path+=./include
set path+=src
set path+=**
function! CheckBackspace() abort
  let col = col('.') - 1
  return !col || getline('.')[col - 1]  =~# '\s'
endfunction
